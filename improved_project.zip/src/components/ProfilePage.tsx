import { useState } from 'react';
import { ArrowLeft, MapPin, Star, Shield, Clock, DollarSign, Award, ExternalLink, Calendar, MessageCircle, FileText, Heart, CheckCircle2, Users } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { VerificationBadge } from './VerificationBadge';
import { SkillTag } from './SkillTag';
import { SpecializationIcon } from './SpecializationIcon';
import { RequestProposalModal } from './RequestProposalModal';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProfilePageProps {
  profileId: string;
  profileType: 'freelancer' | 'cluster';
  onBack: () => void;
}

export function ProfilePage({ profileId, profileType, onBack }: ProfilePageProps) {
  const [proposalModalOpen, setProposalModalOpen] = useState(false);
  const [isShortlisted, setIsShortlisted] = useState(false);

  // Mock data - in real app would fetch based on profileId
  const freelancerProfile = {
    id: profileId,
    name: 'Rajesh Kumar',
    title: 'Senior Embedded Systems Engineer',
    city: 'Bengaluru',
    rating: 4.9,
    reviews: 47,
    verified: true,
    topRated: true,
    backgroundChecked: true,
    yearsExperience: 12,
    projectsCompleted: 32,
    repeatClients: 18,
    responseTime: '< 4 hours',
    availability: 'Available',
    costRange: '₹3-5L',
    timeline: '4-6 weeks',
    about: 'Passionate embedded systems engineer with 12+ years of experience in IoT, automotive, and consumer electronics. Specialized in ARM Cortex-M microcontrollers, real-time operating systems, and low-power design.',
    skills: ['ARM Cortex', 'ESP32', 'FreeRTOS', 'IoT', 'BLE', 'MQTT', 'Low Power Design', 'Sensor Integration'],
    specializations: ['Embedded Systems', 'Firmware', 'IoT'],
    portfolio: [
      {
        id: 1,
        title: 'Smart Home IoT Gateway',
        description: 'Designed and developed ESP32-based IoT gateway for smart home automation',
        image: 'https://images.unsplash.com/photo-1662528600042-f28b7a9e4c75?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxQQ0IlMjBjaXJjdWl0JTIwYm9hcmQlMjBlbGVjdHJvbmljc3xlbnwxfHx8fDE3NjgyMDUxODB8MA&ixlib=rb-4.1.0&q=80&w=1080',
        technologies: ['ESP32', 'MQTT', 'BLE'],
        duration: '3 months'
      },
      {
        id: 2,
        title: 'Wearable Health Tracker',
        description: 'Low-power fitness tracker with heart rate and sleep monitoring',
        image: 'https://images.unsplash.com/photo-1667503779301-3120a323859a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJvbmljcyUyMHByb3RvdHlwZSUyMGxhYiUyMHdvcmtzcGFjZXxlbnwxfHx8fDE3NjgyMDUxOTB8MA&ixlib=rb-4.1.0&q=80&w=1080',
        technologies: ['nRF52', 'FreeRTOS', 'BLE'],
        duration: '4 months'
      },
      {
        id: 3,
        title: 'Industrial Sensor Node',
        description: 'Industrial IoT sensor node for predictive maintenance',
        image: 'https://images.unsplash.com/photo-1562877773-a37120131ec4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2xkZXJpbmclMjBlbGVjdHJvbmljcyUyMHdvcmt8ZW58MXx8fHwxNzY4MjA1MTkxfDA&ixlib=rb-4.1.0&q=80&w=1080',
        technologies: ['STM32', 'LoRaWAN', 'Industrial Protocols'],
        duration: '5 months'
      }
    ],
    reviews: [
      {
        id: 1,
        clientName: 'SmartTech Innovations',
        rating: 5,
        date: 'Nov 2023',
        comment: 'Exceptional work on our IoT gateway project. Rajesh delivered ahead of schedule and the code quality was outstanding. Highly recommended!'
      },
      {
        id: 2,
        clientName: 'HealthWear Devices',
        rating: 5,
        date: 'Sep 2023',
        comment: 'Very knowledgeable and professional. Helped us overcome several technical challenges with our wearable device.'
      },
      {
        id: 3,
        clientName: 'IndustrialSense',
        rating: 4,
        date: 'Jul 2023',
        comment: 'Great technical skills. Communication could be more frequent but overall satisfied with the results.'
      }
    ],
    certifications: [
      'ARM Accredited Engineer',
      'IoT Professional Certification',
      'FreeRTOS Certified Developer'
    ],
    education: 'B.Tech in Electronics & Communication, IIT Bombay'
  };

  const profile = freelancerProfile;

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-white via-blue-50/30 to-cyan-50/20 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Button variant="ghost" onClick={onBack} className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Listings
          </Button>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Info */}
            <div className="lg:col-span-2">
              <div className="flex items-start gap-6 mb-6">
                {/* Avatar */}
                <div className="relative flex-shrink-0">
                  <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[var(--electric-blue)] to-[var(--electric-cyan)] flex items-center justify-center text-white text-3xl font-bold">
                    {profile.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  {profile.verified && (
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-[var(--trust-green)] rounded-full flex items-center justify-center">
                      <Shield className="w-4 h-4 text-white" />
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <h1 className="text-3xl font-bold mb-2">{profile.name}</h1>
                  <p className="text-lg text-muted-foreground mb-3">{profile.title}</p>
                  
                  <div className="flex flex-wrap items-center gap-4 mb-4">
                    <div className="flex items-center gap-1">
                      <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                      <span className="font-semibold">{profile.rating}</span>
                      <span className="text-muted-foreground">({profile.reviews} reviews)</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span>{profile.city}</span>
                    </div>
                    <span className="px-3 py-1 bg-[var(--trust-green)] text-white rounded-full text-sm">
                      {profile.availability}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {profile.verified && <VerificationBadge type="verified" />}
                    {profile.topRated && <VerificationBadge type="top-rated" />}
                    {profile.backgroundChecked && <VerificationBadge type="background-checked" />}
                  </div>
                </div>
              </div>

              {/* Key Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <Card className="p-4">
                  <div className="text-2xl font-bold mb-1">{profile.yearsExperience}</div>
                  <div className="text-xs text-muted-foreground">Years Experience</div>
                </Card>
                <Card className="p-4">
                  <div className="text-2xl font-bold mb-1">{profile.projectsCompleted}</div>
                  <div className="text-xs text-muted-foreground">Projects Done</div>
                </Card>
                <Card className="p-4">
                  <div className="text-2xl font-bold mb-1">{profile.repeatClients}</div>
                  <div className="text-xs text-muted-foreground">Repeat Clients</div>
                </Card>
                <Card className="p-4">
                  <div className="text-2xl font-bold mb-1">{profile.responseTime}</div>
                  <div className="text-xs text-muted-foreground">Response Time</div>
                </Card>
              </div>
            </div>

            {/* Sticky CTA Card */}
            <div className="lg:col-span-1">
              <Card className="p-6 sticky top-24">
                <div className="space-y-4">
                  <div className="pb-4 border-b">
                    <div className="flex items-center gap-2 mb-2">
                      <DollarSign className="w-5 h-5 text-muted-foreground" />
                      <div>
                        <div className="text-xs text-muted-foreground">Cost Range</div>
                        <div className="font-semibold">{profile.costRange}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-muted-foreground" />
                      <div>
                        <div className="text-xs text-muted-foreground">Typical Timeline</div>
                        <div className="font-semibold">{profile.timeline}</div>
                      </div>
                    </div>
                  </div>

                  <Button
                    className="w-full bg-[var(--electric-blue)] hover:bg-[var(--electric-cyan)] text-white"
                    onClick={() => setProposalModalOpen(true)}
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Request Proposal
                  </Button>

                  <Button variant="outline" className="w-full">
                    <Calendar className="w-4 h-4 mr-2" />
                    Book Discovery Call
                  </Button>

                  <Button variant="outline" className="w-full">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Send Message
                  </Button>

                  <Button
                    variant="ghost"
                    className="w-full"
                    onClick={() => setIsShortlisted(!isShortlisted)}
                  >
                    <Heart className={`w-4 h-4 mr-2 ${isShortlisted ? 'fill-red-500 text-red-500' : ''}`} />
                    {isShortlisted ? 'Shortlisted' : 'Add to Shortlist'}
                  </Button>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="w-full justify-start mb-8">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-8">
                {/* About */}
                <Card className="p-6">
                  <h2 className="text-xl font-semibold mb-4">About</h2>
                  <p className="text-muted-foreground leading-relaxed">{profile.about}</p>
                </Card>

                {/* Specializations */}
                <Card className="p-6">
                  <h2 className="text-xl font-semibold mb-4">Specializations</h2>
                  <div className="flex flex-wrap gap-3">
                    {profile.specializations.map((spec) => (
                      <div key={spec} className="flex items-center gap-2 px-4 py-2 bg-secondary rounded-lg">
                        <SpecializationIcon specialization={spec} />
                        <span className="font-medium">{spec}</span>
                      </div>
                    ))}
                  </div>
                </Card>

                {/* Skills */}
                <Card className="p-6">
                  <h2 className="text-xl font-semibold mb-4">Technical Skills</h2>
                  <div className="flex flex-wrap gap-2">
                    {profile.skills.map((skill) => (
                      <SkillTag key={skill} skill={skill} />
                    ))}
                  </div>
                </Card>

                {/* Certifications */}
                <Card className="p-6">
                  <h2 className="text-xl font-semibold mb-4">Certifications & Education</h2>
                  <div className="space-y-3">
                    {profile.certifications.map((cert, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <Award className="w-5 h-5 text-[var(--electric-blue)] flex-shrink-0 mt-0.5" />
                        <span>{cert}</span>
                      </div>
                    ))}
                    <div className="flex items-start gap-2 pt-2 border-t">
                      <CheckCircle2 className="w-5 h-5 text-[var(--trust-green)] flex-shrink-0 mt-0.5" />
                      <span>{profile.education}</span>
                    </div>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="portfolio" className="space-y-6">
                {profile.portfolio.map((project) => (
                  <Card key={project.id} className="overflow-hidden">
                    <div className="md:flex">
                      <div className="md:w-1/3">
                        <ImageWithFallback
                          src={project.image}
                          alt={project.title}
                          className="w-full h-48 md:h-full object-cover"
                        />
                      </div>
                      <div className="p-6 md:w-2/3">
                        <h3 className="text-lg font-semibold mb-2">{project.title}</h3>
                        <p className="text-muted-foreground mb-4">{project.description}</p>
                        <div className="flex flex-wrap gap-2 mb-3">
                          {project.technologies.map((tech) => (
                            <SkillTag key={tech} skill={tech} variant="outline" />
                          ))}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="w-4 h-4" />
                          <span>Duration: {project.duration}</span>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="reviews" className="space-y-6">
                {profile.reviews.map((review) => (
                  <Card key={review.id} className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="font-semibold mb-1">{review.clientName}</div>
                        <div className="flex items-center gap-2">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-4 h-4 ${
                                  i < review.rating
                                    ? 'text-amber-500 fill-amber-500'
                                    : 'text-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-muted-foreground">{review.date}</span>
                        </div>
                      </div>
                    </div>
                    <p className="text-muted-foreground">{review.comment}</p>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Trust Indicators */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Trust & Safety</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[var(--trust-green)] flex-shrink-0" />
                  <div>
                    <div className="font-medium">Identity Verified</div>
                    <div className="text-muted-foreground text-xs">Government ID confirmed</div>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[var(--trust-green)] flex-shrink-0" />
                  <div>
                    <div className="font-medium">Background Checked</div>
                    <div className="text-muted-foreground text-xs">Professional history verified</div>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[var(--trust-green)] flex-shrink-0" />
                  <div>
                    <div className="font-medium">Portfolio Validated</div>
                    <div className="text-muted-foreground text-xs">Projects verified by clients</div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Similar Experts */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Similar Experts</h3>
              <div className="space-y-4">
                {[1, 2].map((i) => (
                  <div key={i} className="flex items-center gap-3 pb-4 border-b last:border-0 last:pb-0">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[var(--electric-blue)] to-[var(--electric-cyan)] flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">Expert Name</div>
                      <div className="text-xs text-muted-foreground">Title</div>
                      <div className="flex items-center gap-1 mt-1">
                        <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                        <span className="text-xs">4.8</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>

      <RequestProposalModal
        isOpen={proposalModalOpen}
        onClose={() => setProposalModalOpen(false)}
        expertName={profile.name}
        expertType={profileType}
      />
    </div>
  );
}
