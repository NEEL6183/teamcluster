import { ArrowRight, CheckCircle2, Users, Shield, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HomePageProps {
  onGetStarted: () => void;
  onStartGuidedFlow: () => void;
}

export function HomePage({ onGetStarted, onStartGuidedFlow }: HomePageProps) {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-white via-blue-50/30 to-cyan-50/20 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left: Hero Content */}
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-[var(--electric-blue)]/10 rounded-full">
                <span className="w-2 h-2 bg-[var(--electric-blue)] rounded-full animate-pulse"></span>
                <span className="text-sm text-[var(--electric-blue)]">Trusted by 200+ Hardware Startups</span>
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight">
                Build Your Hardware Dream Team
              </h1>
              
              <p className="text-lg sm:text-xl text-muted-foreground leading-relaxed">
                Connect with verified electronics experts and execution-ready clusters in your city. 
                From PCB design to manufacturing—find the perfect team to ship your hardware product.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button 
                  size="lg" 
                  className="bg-[var(--electric-blue)] hover:bg-[var(--electric-cyan)] text-white"
                  onClick={onGetStarted}
                >
                  Find Experts in Your City
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  onClick={onStartGuidedFlow}
                >
                  Not sure what you need?
                </Button>
              </div>

              {/* Trust Indicators */}
              <div className="flex flex-wrap gap-6 pt-6 border-t border-border/50">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[var(--trust-green)]" />
                  <span className="text-sm text-muted-foreground">Background Verified</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[var(--trust-green)]" />
                  <span className="text-sm text-muted-foreground">Portfolio Validated</span>
                </div>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-[var(--trust-green)]" />
                  <span className="text-sm text-muted-foreground">Real Reviews</span>
                </div>
              </div>
            </div>

            {/* Right: Hero Image */}
            <div className="relative hidden lg:block">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1662528600042-f28b7a9e4c75?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxQQ0IlMjBjaXJjdWl0JTIwYm9hcmQlMjBlbGVjdHJvbmljc3xlbnwxfHx8fDE3NjgyMDUxODB8MA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="PCB Circuit Board"
                  className="w-full h-[500px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
              </div>
              
              {/* Floating stat cards */}
              <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-lg p-4 border border-border">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-[var(--electric-blue)]/10 rounded-lg flex items-center justify-center">
                    <Users className="w-6 h-6 text-[var(--electric-blue)]" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">500+</div>
                    <div className="text-sm text-muted-foreground">Verified Experts</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Guided Flow Teaser */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Not sure what roles you need? Start with a guided plan.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-[var(--electric-blue)]/10 rounded-full flex items-center justify-center mb-4">
                <span className="text-xl font-bold text-[var(--electric-blue)]">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Tell Us Your Needs</h3>
              <p className="text-muted-foreground">
                Answer a few questions about your hardware project. Our guided flow helps you understand what roles you need.
              </p>
            </Card>

            {/* Step 2 */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-[var(--electric-blue)]/10 rounded-full flex items-center justify-center mb-4">
                <span className="text-xl font-bold text-[var(--electric-blue)]">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Choose Your City & Team Model</h3>
              <p className="text-muted-foreground">
                Find verified freelancers or full hardware clusters in your city. Compare costs, timelines, and portfolios.
              </p>
            </Card>

            {/* Step 3 */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-[var(--electric-blue)]/10 rounded-full flex items-center justify-center mb-4">
                <span className="text-xl font-bold text-[var(--electric-blue)]">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Request Proposals & Ship</h3>
              <p className="text-muted-foreground">
                Request proposals, book discovery calls, and assemble your execution-ready team to ship real products.
              </p>
            </Card>
          </div>

          <div className="text-center mt-10">
            <Button 
              size="lg" 
              variant="outline"
              onClick={onStartGuidedFlow}
              className="border-[var(--electric-blue)] text-[var(--electric-blue)] hover:bg-[var(--electric-blue)]/10"
            >
              Start Guided Setup
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Images Grid */}
            <div className="grid grid-cols-2 gap-4">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1667503779301-3120a323859a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJvbmljcyUyMHByb3RvdHlwZSUyMGxhYiUyMHdvcmtzcGFjZXxlbnwxfHx8fDE3NjgyMDUxOTB8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Electronics Lab"
                className="w-full h-48 object-cover rounded-lg"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1761454165168-cfdf007c6a31?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzRCUyMHByaW50ZXIlMjBwcm90b3R5cGluZ3xlbnwxfHx8fDE3NjgyMDUxOTB8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="3D Printing"
                className="w-full h-48 object-cover rounded-lg mt-6"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1562877773-a37120131ec4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2xkZXJpbmclMjBlbGVjdHJvbmljcyUyMHdvcmt8ZW58MXx8fHwxNzY4MjA1MTkxfDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Soldering Work"
                className="w-full h-48 object-cover rounded-lg"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1662528600042-f28b7a9e4c75?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxQQ0IlMjBjaXJjdWl0JTIwYm9hcmQlMjBlbGVjdHJvbmljc3xlbnwxfHx8fDE3NjgyMDUxODB8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="PCB Design"
                className="w-full h-48 object-cover rounded-lg mt-6"
              />
            </div>

            {/* Content */}
            <div className="space-y-6">
              <h2 className="text-3xl sm:text-4xl font-bold">
                These Experts Have Shipped Real Electronics Products
              </h2>
              <p className="text-lg text-muted-foreground">
                Every expert on our platform is verified and has a proven track record of delivering 
                hardware projects—from prototypes to production.
              </p>
              
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="w-6 h-6 text-[var(--trust-green)] flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold">Portfolio Verification</div>
                    <div className="text-muted-foreground">Real projects, real outcomes</div>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="w-6 h-6 text-[var(--trust-green)] flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold">Background Checks</div>
                    <div className="text-muted-foreground">Professional and reliable</div>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="w-6 h-6 text-[var(--trust-green)] flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold">Client Reviews</div>
                    <div className="text-muted-foreground">Transparent feedback from real startups</div>
                  </div>
                </li>
              </ul>

              <Button 
                size="lg" 
                className="bg-[var(--electric-blue)] hover:bg-[var(--electric-cyan)] text-white"
                onClick={onGetStarted}
              >
                Browse Verified Experts
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
