import { useState } from 'react';
import { Filter, MapPin, X, SlidersHorizontal } from 'lucide-react';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { Label } from './ui/label';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Separator } from './ui/separator';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from './ui/sheet';
import { FreelancerCard } from './FreelancerCard';
import { ClusterCard } from './ClusterCard';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface ListingsPageProps {
  city: string;
  teamModel: 'freelancer' | 'cluster' | 'both';
  onViewProfile: (id: string, type: 'freelancer' | 'cluster') => void;
  onChangeCity: () => void;
}

export function ListingsPage({ city, teamModel, onViewProfile, onChangeCity }: ListingsPageProps) {
  const [filters, setFilters] = useState({
    specializations: [] as string[],
    verified: false,
    topRated: false,
    availability: 'all',
    costRange: 'all',
    sortBy: 'relevance'
  });

  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const specializations = [
    'Embedded Systems',
    'PCB Design',
    'Firmware',
    'Mechanical',
    'Industrial Design',
    'QA Testing',
    'Manufacturing'
  ];

  // Mock data
  const freelancers = [
    {
      id: 'f1',
      name: 'Rajesh Kumar',
      title: 'Senior Embedded Systems Engineer',
      city: city,
      rating: 4.9,
      reviews: 47,
      verified: true,
      topRated: true,
      skills: ['ARM Cortex', 'ESP32', 'FreeRTOS', 'IoT', 'BLE'],
      costRange: '₹3-5L',
      timeline: '4-6 weeks',
      projectsCompleted: 32,
      availability: 'Available' as const
    },
    {
      id: 'f2',
      name: 'Priya Sharma',
      title: 'PCB Design Specialist',
      city: city,
      rating: 4.8,
      reviews: 38,
      verified: true,
      topRated: false,
      skills: ['Altium', 'OrCAD', 'High-Speed PCB', 'RF Design', 'EMI/EMC'],
      costRange: '₹2-4L',
      timeline: '3-5 weeks',
      projectsCompleted: 45,
      availability: 'Busy' as const
    },
    {
      id: 'f3',
      name: 'Amit Patel',
      title: 'Firmware Developer',
      city: city,
      rating: 4.7,
      reviews: 29,
      verified: true,
      topRated: false,
      skills: ['C/C++', 'RTOS', 'Device Drivers', 'Bootloaders', 'Linux'],
      costRange: '₹4-6L',
      timeline: '6-8 weeks',
      projectsCompleted: 28,
      availability: 'Available' as const
    },
    {
      id: 'f4',
      name: 'Sneha Desai',
      title: 'Mechanical Design Engineer',
      city: city,
      rating: 4.9,
      reviews: 52,
      verified: true,
      topRated: true,
      skills: ['SolidWorks', 'CAD', 'DFM', 'Enclosure Design', '3D Printing'],
      costRange: '₹3-5L',
      timeline: '4-6 weeks',
      projectsCompleted: 41,
      availability: 'Available' as const
    }
  ];

  const clusters = [
    {
      id: 'c1',
      name: 'TechForge Hardware Labs',
      tagline: 'End-to-end hardware development',
      city: city,
      teamSize: 8,
      rating: 4.9,
      reviews: 23,
      verified: true,
      specializations: ['Embedded', 'PCB Design', 'Firmware', 'Mechanical'],
      capabilities: ['IoT Products', 'Medical Devices', 'Consumer Electronics'],
      costRange: '₹15-25L',
      timeline: '3-4 months',
      projectsCompleted: 18,
      availability: 'Available' as const
    },
    {
      id: 'c2',
      name: 'Circuit Innovators',
      tagline: 'Specialized in complex PCB systems',
      city: city,
      teamSize: 6,
      rating: 4.8,
      reviews: 19,
      verified: true,
      specializations: ['PCB Design', 'Firmware', 'QA Testing'],
      capabilities: ['High-Speed Design', 'Power Electronics', 'Automotive'],
      costRange: '₹20-35L',
      timeline: '4-5 months',
      projectsCompleted: 15,
      availability: 'Limited' as const
    },
    {
      id: 'c3',
      name: 'ProtoMakers Studio',
      tagline: 'Rapid prototyping to production',
      city: city,
      teamSize: 10,
      rating: 4.7,
      reviews: 31,
      verified: true,
      specializations: ['Embedded', 'Mechanical', 'Industrial Design', 'Manufacturing'],
      capabilities: ['Product Design', 'DFM', 'Supply Chain', 'Quality Control'],
      costRange: '₹25-40L',
      timeline: '4-6 months',
      projectsCompleted: 24,
      availability: 'Available' as const
    }
  ];

  const toggleSpecialization = (spec: string) => {
    setFilters(prev => ({
      ...prev,
      specializations: prev.specializations.includes(spec)
        ? prev.specializations.filter(s => s !== spec)
        : [...prev.specializations, spec]
    }));
  };

  const clearFilters = () => {
    setFilters({
      specializations: [],
      verified: false,
      topRated: false,
      availability: 'all',
      costRange: 'all',
      sortBy: 'relevance'
    });
  };

  const activeFiltersCount = 
    filters.specializations.length +
    (filters.verified ? 1 : 0) +
    (filters.topRated ? 1 : 0) +
    (filters.availability !== 'all' ? 1 : 0) +
    (filters.costRange !== 'all' ? 1 : 0);

  const FilterSection = () => (
    <div className="space-y-6">
      {/* City */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold">City</h3>
        </div>
        <Button
          variant="outline"
          className="w-full justify-start"
          onClick={onChangeCity}
        >
          <MapPin className="w-4 h-4 mr-2" />
          {city}
        </Button>
      </div>

      <Separator />

      {/* Team Model */}
      <div>
        <h3 className="font-semibold mb-3">Showing</h3>
        <div className="space-y-2 text-sm">
          {teamModel === 'both' && <p className="text-muted-foreground">All experts & teams</p>}
          {teamModel === 'freelancer' && <p className="text-muted-foreground">Individual freelancers only</p>}
          {teamModel === 'cluster' && <p className="text-muted-foreground">Hardware clusters only</p>}
        </div>
      </div>

      <Separator />

      {/* Specializations */}
      <div>
        <h3 className="font-semibold mb-3">Specializations</h3>
        <div className="space-y-2">
          {specializations.map((spec) => (
            <label key={spec} className="flex items-center gap-2 cursor-pointer">
              <Checkbox
                checked={filters.specializations.includes(spec)}
                onCheckedChange={() => toggleSpecialization(spec)}
              />
              <span className="text-sm">{spec}</span>
            </label>
          ))}
        </div>
      </div>

      <Separator />

      {/* Verification */}
      <div>
        <h3 className="font-semibold mb-3">Trust & Quality</h3>
        <div className="space-y-2">
          <label className="flex items-center gap-2 cursor-pointer">
            <Checkbox
              checked={filters.verified}
              onCheckedChange={(checked) => setFilters({ ...filters, verified: !!checked })}
            />
            <span className="text-sm">Verified Only</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <Checkbox
              checked={filters.topRated}
              onCheckedChange={(checked) => setFilters({ ...filters, topRated: !!checked })}
            />
            <span className="text-sm">Top Rated (4.5+)</span>
          </label>
        </div>
      </div>

      <Separator />

      {/* Availability */}
      <div>
        <h3 className="font-semibold mb-3">Availability</h3>
        <RadioGroup value={filters.availability} onValueChange={(value) => setFilters({ ...filters, availability: value })}>
          <div className="space-y-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <RadioGroupItem value="all" id="avail-all" />
              <Label htmlFor="avail-all" className="cursor-pointer text-sm">All</Label>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <RadioGroupItem value="available" id="avail-available" />
              <Label htmlFor="avail-available" className="cursor-pointer text-sm">Available Now</Label>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <RadioGroupItem value="soon" id="avail-soon" />
              <Label htmlFor="avail-soon" className="cursor-pointer text-sm">Available Soon</Label>
            </label>
          </div>
        </RadioGroup>
      </div>

      <Separator />

      {/* Cost Range */}
      <div>
        <h3 className="font-semibold mb-3">Cost Range</h3>
        <RadioGroup value={filters.costRange} onValueChange={(value) => setFilters({ ...filters, costRange: value })}>
          <div className="space-y-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <RadioGroupItem value="all" id="cost-all" />
              <Label htmlFor="cost-all" className="cursor-pointer text-sm">All Budgets</Label>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <RadioGroupItem value="low" id="cost-low" />
              <Label htmlFor="cost-low" className="cursor-pointer text-sm">₹2-5L</Label>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <RadioGroupItem value="medium" id="cost-medium" />
              <Label htmlFor="cost-medium" className="cursor-pointer text-sm">₹5-15L</Label>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <RadioGroupItem value="high" id="cost-high" />
              <Label htmlFor="cost-high" className="cursor-pointer text-sm">₹15L+</Label>
            </label>
          </div>
        </RadioGroup>
      </div>

      {activeFiltersCount > 0 && (
        <>
          <Separator />
          <Button variant="ghost" className="w-full" onClick={clearFilters}>
            Clear All Filters
          </Button>
        </>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <div>
              <h1 className="text-3xl font-bold mb-2">
                {teamModel === 'both' && 'Experts & Teams'}
                {teamModel === 'freelancer' && 'Freelance Experts'}
                {teamModel === 'cluster' && 'Hardware Clusters'}
              </h1>
              <p className="text-muted-foreground">
                {city} • {freelancers.length + (teamModel !== 'freelancer' ? clusters.length : 0)} results
              </p>
            </div>

            {/* Sort */}
            <div className="flex items-center gap-3">
              <Select value={filters.sortBy} onValueChange={(value) => setFilters({ ...filters, sortBy: value })}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevance">Most Relevant</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                  <SelectItem value="reviews">Most Reviews</SelectItem>
                  <SelectItem value="projects">Most Projects</SelectItem>
                </SelectContent>
              </Select>

              {/* Mobile Filter Toggle */}
              <Sheet open={mobileFiltersOpen} onOpenChange={setMobileFiltersOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden">
                    <SlidersHorizontal className="w-4 h-4 mr-2" />
                    Filters
                    {activeFiltersCount > 0 && (
                      <span className="ml-2 px-2 py-0.5 bg-primary text-primary-foreground rounded-full text-xs">
                        {activeFiltersCount}
                      </span>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80 overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>Filters</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6">
                    <FilterSection />
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>

          {/* Active Filters */}
          {activeFiltersCount > 0 && (
            <div className="flex flex-wrap gap-2">
              {filters.specializations.map((spec) => (
                <span
                  key={spec}
                  className="inline-flex items-center gap-1 px-3 py-1 bg-[var(--electric-blue)]/10 text-[var(--electric-blue)] rounded-full text-sm"
                >
                  {spec}
                  <button onClick={() => toggleSpecialization(spec)} className="hover:bg-[var(--electric-blue)]/20 rounded-full p-0.5">
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
              {filters.verified && (
                <span className="inline-flex items-center gap-1 px-3 py-1 bg-[var(--trust-green)]/10 text-[var(--trust-green)] rounded-full text-sm">
                  Verified
                </span>
              )}
              {filters.topRated && (
                <span className="inline-flex items-center gap-1 px-3 py-1 bg-amber-100 text-amber-900 rounded-full text-sm">
                  Top Rated
                </span>
              )}
            </div>
          )}
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Desktop Filters Sidebar */}
          <aside className="hidden lg:block">
            <div className="sticky top-24 bg-white rounded-lg border p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold">Filters</h2>
                {activeFiltersCount > 0 && (
                  <span className="px-2 py-0.5 bg-primary text-primary-foreground rounded-full text-xs">
                    {activeFiltersCount}
                  </span>
                )}
              </div>
              <FilterSection />
            </div>
          </aside>

          {/* Listings */}
          <div className="lg:col-span-3">
            <div className="space-y-6">
              {/* Clusters */}
              {(teamModel === 'cluster' || teamModel === 'both') && clusters.length > 0 && (
                <div>
                  {teamModel === 'both' && (
                    <h2 className="text-xl font-semibold mb-4">Hardware Clusters ({clusters.length})</h2>
                  )}
                  <div className="grid md:grid-cols-2 gap-6">
                    {clusters.map((cluster) => (
                      <ClusterCard
                        key={cluster.id}
                        cluster={cluster}
                        onViewProfile={(id) => onViewProfile(id, 'cluster')}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Freelancers */}
              {(teamModel === 'freelancer' || teamModel === 'both') && freelancers.length > 0 && (
                <div>
                  {teamModel === 'both' && (
                    <h2 className="text-xl font-semibold mb-4 mt-8">Individual Freelancers ({freelancers.length})</h2>
                  )}
                  <div className="grid md:grid-cols-2 gap-6">
                    {freelancers.map((freelancer) => (
                      <FreelancerCard
                        key={freelancer.id}
                        freelancer={freelancer}
                        onViewProfile={(id) => onViewProfile(id, 'freelancer')}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
