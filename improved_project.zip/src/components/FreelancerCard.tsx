import { MapPin, Star, Shield, Clock, DollarSign, Heart, ExternalLink } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { VerificationBadge } from './VerificationBadge';
import { SkillTag } from './SkillTag';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface FreelancerCardProps {
  freelancer: {
    id: string;
    name: string;
    title: string;
    city: string;
    avatar?: string;
    rating: number;
    reviews: number;
    verified: boolean;
    topRated: boolean;
    skills: string[];
    costRange: string;
    timeline: string;
    projectsCompleted: number;
    availability: 'Available' | 'Busy' | 'Booked';
  };
  onViewProfile: (id: string) => void;
  onShortlist?: (id: string) => void;
}

export function FreelancerCard({ freelancer, onViewProfile, onShortlist }: FreelancerCardProps) {
  const availabilityColors = {
    'Available': 'bg-[var(--trust-green)] text-white',
    'Busy': 'bg-amber-500 text-white',
    'Booked': 'bg-gray-400 text-white'
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all group">
      <div className="p-6">
        {/* Header */}
        <div className="flex items-start gap-4 mb-4">
          {/* Avatar */}
          <div className="relative flex-shrink-0">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[var(--electric-blue)] to-[var(--electric-cyan)] flex items-center justify-center text-white text-xl font-bold">
              {freelancer.name.split(' ').map(n => n[0]).join('')}
            </div>
            {freelancer.verified && (
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-[var(--trust-green)] rounded-full flex items-center justify-center">
                <Shield className="w-3 h-3 text-white" />
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-1">
              <h3 className="font-semibold text-lg truncate">{freelancer.name}</h3>
              {onShortlist && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="flex-shrink-0 p-2 h-auto"
                  onClick={() => onShortlist(freelancer.id)}
                >
                  <Heart className="w-4 h-4" />
                </Button>
              )}
            </div>
            <p className="text-sm text-muted-foreground mb-2">{freelancer.title}</p>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <MapPin className="w-4 h-4" />
              <span>{freelancer.city}</span>
            </div>
          </div>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-2 mb-4">
          {freelancer.verified && <VerificationBadge type="verified" />}
          {freelancer.topRated && <VerificationBadge type="top-rated" />}
          <span className={`px-2 py-1 rounded text-xs font-medium ${availabilityColors[freelancer.availability]}`}>
            {freelancer.availability}
          </span>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 mb-4 pb-4 border-b">
          <div>
            <div className="flex items-center gap-1 mb-1">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span className="font-semibold">{freelancer.rating}</span>
              <span className="text-sm text-muted-foreground">({freelancer.reviews})</span>
            </div>
            <p className="text-xs text-muted-foreground">Rating</p>
          </div>
          <div>
            <div className="font-semibold mb-1">{freelancer.projectsCompleted}</div>
            <p className="text-xs text-muted-foreground">Projects Completed</p>
          </div>
        </div>

        {/* Skills */}
        <div className="mb-4">
          <div className="flex flex-wrap gap-2">
            {freelancer.skills.slice(0, 4).map((skill) => (
              <SkillTag key={skill} skill={skill} variant="secondary" />
            ))}
            {freelancer.skills.length > 4 && (
              <SkillTag skill={`+${freelancer.skills.length - 4} more`} variant="outline" />
            )}
          </div>
        </div>

        {/* Cost & Timeline */}
        <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-muted-foreground" />
            <div>
              <div className="text-xs text-muted-foreground">Cost Range</div>
              <div className="font-semibold">{freelancer.costRange}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-muted-foreground" />
            <div>
              <div className="text-xs text-muted-foreground">Typical Timeline</div>
              <div className="font-semibold">{freelancer.timeline}</div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            className="flex-1 bg-[var(--electric-blue)] hover:bg-[var(--electric-cyan)] text-white"
            onClick={() => onViewProfile(freelancer.id)}
          >
            View Profile
          </Button>
          <Button variant="outline" size="icon">
            <ExternalLink className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}
