import { Badge } from './ui/badge';

interface SkillTagProps {
  skill: string;
  count?: number;
  variant?: 'default' | 'secondary' | 'outline';
  className?: string;
}

export function SkillTag({ skill, count, variant = 'secondary', className }: SkillTagProps) {
  return (
    <Badge variant={variant} className={`${className}`}>
      {skill}
      {count && <span className="ml-1 opacity-60">({count})</span>}
    </Badge>
  );
}
