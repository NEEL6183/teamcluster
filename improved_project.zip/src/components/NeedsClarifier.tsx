import { useState } from 'react';
import { ArrowRight, ArrowLeft, CheckCircle2, HelpCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { SpecializationIcon } from './SpecializationIcon';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';

interface NeedsClarifierProps {
  onComplete: (needs: any) => void;
  onBack: () => void;
}

export function NeedsClarifier({ onComplete, onBack }: NeedsClarifierProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    stage: '',
    roles: [] as string[],
    teamModel: '',
    budget: '',
    timeline: ''
  });

  const totalSteps = 5;

  const roles = [
    { id: 'embedded', label: 'Embedded Systems', description: 'Microcontroller programming, IoT' },
    { id: 'pcb', label: 'PCB Design', description: 'Circuit design, schematic capture' },
    { id: 'firmware', label: 'Firmware', description: 'Low-level software, drivers' },
    { id: 'mechanical', label: 'Mechanical Engineering', description: 'CAD, enclosure design' },
    { id: 'industrial', label: 'Industrial Design', description: 'Product aesthetics, UX' },
    { id: 'qa', label: 'QA Testing', description: 'Quality assurance, certification' },
    { id: 'manufacturing', label: 'Manufacturing', description: 'Production scaling, sourcing' },
  ];

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      onComplete(formData);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    } else {
      onBack();
    }
  };

  const toggleRole = (roleId: string) => {
    setFormData(prev => ({
      ...prev,
      roles: prev.roles.includes(roleId)
        ? prev.roles.filter(r => r !== roleId)
        : [...prev.roles, roleId]
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-blue-50/30 to-cyan-50/20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Step {step} of {totalSteps}</span>
            <span className="text-sm text-muted-foreground">{Math.round((step / totalSteps) * 100)}% Complete</span>
          </div>
          <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-[var(--electric-blue)] transition-all duration-300"
              style={{ width: `${(step / totalSteps) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Content */}
        <Card className="p-8 sm:p-12 bg-white shadow-lg">
          {/* Step 1: Project Stage */}
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-3xl font-bold mb-2">What stage is your project at?</h2>
                <p className="text-muted-foreground">This helps us recommend the right expertise level.</p>
              </div>

              <RadioGroup value={formData.stage} onValueChange={(value) => setFormData({ ...formData, stage: value })}>
                <div className="space-y-3">
                  <label className="flex items-start gap-4 p-4 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="concept" id="concept" className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor="concept" className="cursor-pointer">
                        <div className="font-semibold">Concept / Idea Stage</div>
                        <div className="text-sm text-muted-foreground">Need help validating and prototyping</div>
                      </Label>
                    </div>
                  </label>

                  <label className="flex items-start gap-4 p-4 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="prototype" id="prototype" className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor="prototype" className="cursor-pointer">
                        <div className="font-semibold">Working Prototype</div>
                        <div className="text-sm text-muted-foreground">Have a prototype, need to refine or scale</div>
                      </Label>
                    </div>
                  </label>

                  <label className="flex items-start gap-4 p-4 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="production" id="production" className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor="production" className="cursor-pointer">
                        <div className="font-semibold">Ready for Production</div>
                        <div className="text-sm text-muted-foreground">Need manufacturing and scaling support</div>
                      </Label>
                    </div>
                  </label>
                </div>
              </RadioGroup>
            </div>
          )}

          {/* Step 2: Roles Needed */}
          {step === 2 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-3xl font-bold mb-2">What roles do you need?</h2>
                <p className="text-muted-foreground">Select all that apply. Not sure? We'll help you decide.</p>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                {roles.map((role) => (
                  <label
                    key={role.id}
                    className={`flex items-start gap-3 p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                      formData.roles.includes(role.id) 
                        ? 'border-[var(--electric-blue)] bg-[var(--electric-blue)]/5' 
                        : 'hover:border-[var(--electric-blue)]/50'
                    }`}
                  >
                    <Checkbox
                      checked={formData.roles.includes(role.id)}
                      onCheckedChange={() => toggleRole(role.id)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <SpecializationIcon specialization={role.label} className="w-4 h-4" />
                        <div className="font-semibold">{role.label}</div>
                      </div>
                      <div className="text-sm text-muted-foreground">{role.description}</div>
                    </div>
                  </label>
                ))}
              </div>

              <div className="flex items-start gap-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <HelpCircle className="w-5 h-5 text-[var(--electric-blue)] flex-shrink-0 mt-0.5" />
                <div className="text-sm">
                  <span className="font-semibold text-foreground">Not sure what you need?</span>
                  <p className="text-muted-foreground mt-1">
                    Most hardware startups need at least PCB Design, Firmware, and Mechanical Engineering. 
                    Industrial Design and Manufacturing come later.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Team Model */}
          {step === 3 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-3xl font-bold mb-2">Choose between freelancers or a cluster</h2>
                <p className="text-muted-foreground">Different models work for different needs.</p>
              </div>

              <RadioGroup value={formData.teamModel} onValueChange={(value) => setFormData({ ...formData, teamModel: value })}>
                <div className="space-y-4">
                  <label className="flex items-start gap-4 p-6 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="freelancer" id="freelancer" className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor="freelancer" className="cursor-pointer">
                        <div className="font-semibold text-lg mb-2">Individual Freelancers</div>
                        <div className="text-sm text-muted-foreground mb-3">
                          Hire specialists one by one. You coordinate the team.
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <span className="px-2 py-1 bg-[var(--trust-green)]/10 text-[var(--trust-green)] text-xs rounded">
                            Lower initial cost
                          </span>
                          <span className="px-2 py-1 bg-[var(--trust-green)]/10 text-[var(--trust-green)] text-xs rounded">
                            More flexibility
                          </span>
                          <span className="px-2 py-1 bg-amber-100 text-amber-900 text-xs rounded">
                            You manage coordination
                          </span>
                        </div>
                      </Label>
                    </div>
                  </label>

                  <label className="flex items-start gap-4 p-6 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="cluster" id="cluster" className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor="cluster" className="cursor-pointer">
                        <div className="font-semibold text-lg mb-2">Hardware Cluster (Team)</div>
                        <div className="text-sm text-muted-foreground mb-3">
                          Pre-coordinated team with all roles. Single point of contact.
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <span className="px-2 py-1 bg-[var(--trust-green)]/10 text-[var(--trust-green)] text-xs rounded">
                            Faster execution
                          </span>
                          <span className="px-2 py-1 bg-[var(--trust-green)]/10 text-[var(--trust-green)] text-xs rounded">
                            Proven collaboration
                          </span>
                          <span className="px-2 py-1 bg-[var(--trust-green)]/10 text-[var(--trust-green)] text-xs rounded">
                            Single accountability
                          </span>
                        </div>
                      </Label>
                    </div>
                  </label>

                  <label className="flex items-start gap-4 p-6 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="both" id="both" className="mt-1" />
                    <div className="flex-1">
                      <Label htmlFor="both" className="cursor-pointer">
                        <div className="font-semibold text-lg mb-2">Show Me Both</div>
                        <div className="text-sm text-muted-foreground">
                          I want to compare options and decide later
                        </div>
                      </Label>
                    </div>
                  </label>
                </div>
              </RadioGroup>
            </div>
          )}

          {/* Step 4: Budget */}
          {step === 4 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-3xl font-bold mb-2">What's your approximate budget?</h2>
                <p className="text-muted-foreground">This helps us show relevant options. You can adjust later.</p>
              </div>

              <RadioGroup value={formData.budget} onValueChange={(value) => setFormData({ ...formData, budget: value })}>
                <div className="space-y-3">
                  <label className="flex items-center gap-4 p-4 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="budget1" id="budget1" />
                    <Label htmlFor="budget1" className="cursor-pointer flex-1">
                      <div className="font-semibold">₹2-5 Lakhs</div>
                      <div className="text-sm text-muted-foreground">Small prototype or specific component</div>
                    </Label>
                  </label>

                  <label className="flex items-center gap-4 p-4 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="budget2" id="budget2" />
                    <Label htmlFor="budget2" className="cursor-pointer flex-1">
                      <div className="font-semibold">₹5-15 Lakhs</div>
                      <div className="text-sm text-muted-foreground">Full prototype with multiple disciplines</div>
                    </Label>
                  </label>

                  <label className="flex items-center gap-4 p-4 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="budget3" id="budget3" />
                    <Label htmlFor="budget3" className="cursor-pointer flex-1">
                      <div className="font-semibold">₹15-30 Lakhs</div>
                      <div className="text-sm text-muted-foreground">Advanced development & small batch production</div>
                    </Label>
                  </label>

                  <label className="flex items-center gap-4 p-4 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="budget4" id="budget4" />
                    <Label htmlFor="budget4" className="cursor-pointer flex-1">
                      <div className="font-semibold">₹30+ Lakhs</div>
                      <div className="text-sm text-muted-foreground">Large scale production or complex systems</div>
                    </Label>
                  </label>
                </div>
              </RadioGroup>
            </div>
          )}

          {/* Step 5: Timeline */}
          {step === 5 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-3xl font-bold mb-2">What's your target timeline?</h2>
                <p className="text-muted-foreground">We'll match you with experts who can meet your deadlines.</p>
              </div>

              <RadioGroup value={formData.timeline} onValueChange={(value) => setFormData({ ...formData, timeline: value })}>
                <div className="space-y-3">
                  <label className="flex items-center gap-4 p-4 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="urgent" id="urgent" />
                    <Label htmlFor="urgent" className="cursor-pointer flex-1">
                      <div className="font-semibold">1-2 months (Urgent)</div>
                      <div className="text-sm text-muted-foreground">Need rapid execution</div>
                    </Label>
                  </label>

                  <label className="flex items-center gap-4 p-4 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="normal" id="normal" />
                    <Label htmlFor="normal" className="cursor-pointer flex-1">
                      <div className="font-semibold">3-6 months (Standard)</div>
                      <div className="text-sm text-muted-foreground">Normal development cycle</div>
                    </Label>
                  </label>

                  <label className="flex items-center gap-4 p-4 border-2 rounded-lg cursor-pointer hover:border-[var(--electric-blue)] transition-colors">
                    <RadioGroupItem value="flexible" id="flexible" />
                    <Label htmlFor="flexible" className="cursor-pointer flex-1">
                      <div className="font-semibold">6+ months (Flexible)</div>
                      <div className="text-sm text-muted-foreground">Can work around expert availability</div>
                    </Label>
                  </label>
                </div>
              </RadioGroup>

              <div className="mt-8 p-6 bg-[var(--trust-green)]/10 border-2 border-[var(--trust-green)]/30 rounded-lg">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-6 h-6 text-[var(--trust-green)] flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-lg mb-2">You're all set!</div>
                    <p className="text-muted-foreground text-sm">
                      Based on your inputs, we'll show you the most relevant experts and teams in your city.
                      You can refine your search anytime.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between pt-8 mt-8 border-t">
            <Button
              variant="ghost"
              onClick={handleBack}
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>

            <Button
              onClick={handleNext}
              className="bg-[var(--electric-blue)] hover:bg-[var(--electric-cyan)] text-white gap-2"
              disabled={
                (step === 1 && !formData.stage) ||
                (step === 2 && formData.roles.length === 0) ||
                (step === 3 && !formData.teamModel) ||
                (step === 4 && !formData.budget) ||
                (step === 5 && !formData.timeline)
              }
            >
              {step === totalSteps ? 'View Results' : 'Continue'}
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
