import { Shield, CheckCircle2, Award } from 'lucide-react';
import { Badge } from './ui/badge';

interface VerificationBadgeProps {
  type: 'verified' | 'top-rated' | 'background-checked';
  className?: string;
}

export function VerificationBadge({ type, className }: VerificationBadgeProps) {
  const badges = {
    'verified': {
      icon: Shield,
      label: 'Verified',
      variant: 'default' as const,
      color: 'bg-[var(--trust-green)] text-white hover:bg-[var(--trust-green)]'
    },
    'top-rated': {
      icon: Award,
      label: 'Top Rated',
      variant: 'secondary' as const,
      color: 'bg-amber-100 text-amber-900 hover:bg-amber-100'
    },
    'background-checked': {
      icon: CheckCircle2,
      label: 'Background Checked',
      variant: 'outline' as const,
      color: 'border-[var(--trust-green)] text-[var(--trust-green)]'
    }
  };

  const badge = badges[type];
  const Icon = badge.icon;

  return (
    <Badge variant={badge.variant} className={`${badge.color} ${className} flex items-center gap-1`}>
      <Icon className="w-3 h-3" />
      {badge.label}
    </Badge>
  );
}
