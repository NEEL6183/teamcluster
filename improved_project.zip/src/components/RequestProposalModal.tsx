import { useState } from 'react';
import { ArrowLeft, Send, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Checkbox } from './ui/checkbox';

interface RequestProposalModalProps {
  isOpen: boolean;
  onClose: () => void;
  expertName: string;
  expertType: 'freelancer' | 'cluster';
}

export function RequestProposalModal({ isOpen, onClose, expertName, expertType }: RequestProposalModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    projectDescription: '',
    budget: '',
    timeline: '',
    nda: false
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Proposal request submitted:', formData);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Request Proposal from {expertName}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          {/* Your Information */}
          <div className="space-y-4">
            <h3 className="font-semibold">Your Information</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  placeholder="Your name"
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  placeholder="your@email.com"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="company">Company / Startup Name</Label>
              <Input
                id="company"
                value={formData.company}
                onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                placeholder="Your company name"
              />
            </div>
          </div>

          {/* Project Details */}
          <div className="space-y-4">
            <h3 className="font-semibold">Project Details</h3>
            <div>
              <Label htmlFor="description">Project Description *</Label>
              <Textarea
                id="description"
                value={formData.projectDescription}
                onChange={(e) => setFormData({ ...formData, projectDescription: e.target.value })}
                required
                rows={5}
                placeholder="Describe your project, requirements, and what you're looking for..."
                className="resize-none"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Include key requirements, technical challenges, and expected outcomes
              </p>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="budget">Budget Range</Label>
                <select
                  id="budget"
                  value={formData.budget}
                  onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                  className="w-full h-10 px-3 py-2 bg-input-background rounded-md border border-border"
                >
                  <option value="">Select budget</option>
                  <option value="2-5">₹2-5 Lakhs</option>
                  <option value="5-10">₹5-10 Lakhs</option>
                  <option value="10-20">₹10-20 Lakhs</option>
                  <option value="20-40">₹20-40 Lakhs</option>
                  <option value="40+">₹40+ Lakhs</option>
                </select>
              </div>
              <div>
                <Label htmlFor="timeline">Desired Timeline</Label>
                <select
                  id="timeline"
                  value={formData.timeline}
                  onChange={(e) => setFormData({ ...formData, timeline: e.target.value })}
                  className="w-full h-10 px-3 py-2 bg-input-background rounded-md border border-border"
                >
                  <option value="">Select timeline</option>
                  <option value="urgent">1-2 months (Urgent)</option>
                  <option value="normal">3-6 months</option>
                  <option value="flexible">6+ months</option>
                </select>
              </div>
            </div>
          </div>

          {/* NDA */}
          <div className="flex items-start gap-3 p-4 bg-muted/30 rounded-lg">
            <Checkbox
              id="nda"
              checked={formData.nda}
              onCheckedChange={(checked) => setFormData({ ...formData, nda: !!checked })}
            />
            <div className="flex-1">
              <Label htmlFor="nda" className="cursor-pointer font-normal">
                I would like to discuss this project under NDA
              </Label>
              <p className="text-xs text-muted-foreground mt-1">
                {expertName} will be notified of your NDA requirement before viewing details
              </p>
            </div>
          </div>

          {/* What Happens Next */}
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h4 className="font-semibold text-sm mb-2">What happens next?</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• {expertName} will receive your proposal request</li>
              <li>• They typically respond within 24-48 hours</li>
              <li>• You'll receive a detailed proposal with costs & timeline</li>
              <li>• You can then schedule a discovery call</li>
            </ul>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="flex-1 bg-[var(--electric-blue)] hover:bg-[var(--electric-cyan)] text-white"
            >
              <Send className="w-4 h-4 mr-2" />
              Send Request
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
