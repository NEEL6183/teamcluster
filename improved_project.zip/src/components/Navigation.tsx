import { MapPin, Menu } from 'lucide-react';
import { Button } from './ui/button';
import { useState } from 'react';

interface NavigationProps {
  selectedCity?: string;
  onCityClick: () => void;
  showMobileMenu?: boolean;
}

export function Navigation({ selectedCity, onCityClick, showMobileMenu = false }: NavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">CM</span>
              </div>
              <span className="font-semibold hidden sm:inline">Cluster Marketplace</span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-6">
              <a href="#" className="text-sm text-foreground hover:text-primary transition-colors">
                Find Experts
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                How It Works
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Success Stories
              </a>
            </div>
          </div>

          {/* Right side */}
          <div className="flex items-center gap-3">
            {/* City selector */}
            {selectedCity && (
              <Button
                variant="outline"
                size="sm"
                onClick={onCityClick}
                className="hidden sm:flex items-center gap-2"
              >
                <MapPin className="w-4 h-4" />
                <span>{selectedCity}</span>
              </Button>
            )}

            {/* CTA Buttons */}
            <Button variant="ghost" size="sm" className="hidden lg:inline-flex">
              For Vendors
            </Button>
            <Button size="sm" className="bg-[var(--electric-blue)] hover:bg-[var(--electric-cyan)] text-white">
              Get Started
            </Button>

            {/* Mobile menu button */}
            {showMobileMenu && (
              <Button
                variant="ghost"
                size="sm"
                className="md:hidden"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                <Menu className="w-5 h-5" />
              </Button>
            )}
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-2 border-t">
            <a href="#" className="block px-3 py-2 text-sm font-medium hover:bg-muted rounded-md">
              Find Experts
            </a>
            <a href="#" className="block px-3 py-2 text-sm text-muted-foreground hover:bg-muted rounded-md">
              How It Works
            </a>
            <a href="#" className="block px-3 py-2 text-sm text-muted-foreground hover:bg-muted rounded-md">
              Success Stories
            </a>
            {selectedCity && (
              <button
                onClick={onCityClick}
                className="w-full text-left px-3 py-2 text-sm text-muted-foreground hover:bg-muted rounded-md flex items-center gap-2"
              >
                <MapPin className="w-4 h-4" />
                Change City: {selectedCity}
              </button>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}
