import { Users, User, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';

interface ClusterVsFreelancerProps {
  onSelectModel: (model: 'cluster' | 'freelancer' | 'both') => void;
  onBack: () => void;
}

export function ClusterVsFreelancer({ onSelectModel, onBack }: ClusterVsFreelancerProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-blue-50/30 to-cyan-50/20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            Choose Your Team Model
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose between freelance talent or full hardware clusters based on your project needs.
          </p>
        </div>

        {/* Comparison Cards */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Freelancers */}
          <Card className="p-8 border-2 hover:border-[var(--electric-blue)] transition-all hover:shadow-xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <User className="w-6 h-6 text-[var(--electric-blue)]" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Individual Freelancers</h2>
                <p className="text-sm text-muted-foreground">Build your own team</p>
              </div>
            </div>

            <div className="space-y-6 mb-8">
              {/* Pros */}
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[var(--trust-green)]" />
                  Best For
                </h3>
                <ul className="space-y-2 text-sm text-muted-foreground pl-7">
                  <li>• Startups with clear technical requirements</li>
                  <li>• Projects needing specialized niche skills</li>
                  <li>• Teams with in-house technical leadership</li>
                  <li>• Budget-conscious early-stage projects</li>
                </ul>
              </div>

              {/* Pros */}
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[var(--trust-green)]" />
                  Advantages
                </h3>
                <ul className="space-y-2 text-sm text-muted-foreground pl-7">
                  <li>• Lower initial costs</li>
                  <li>• Flexibility to scale team up or down</li>
                  <li>• Direct access to individual specialists</li>
                  <li>• More control over team composition</li>
                </ul>
              </div>

              {/* Considerations */}
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-amber-600" />
                  Considerations
                </h3>
                <ul className="space-y-2 text-sm text-muted-foreground pl-7">
                  <li>• You manage coordination between experts</li>
                  <li>• May need separate contracts with each</li>
                  <li>• Requires time to build team chemistry</li>
                  <li>• More moving parts to track</li>
                </ul>
              </div>
            </div>

            <div className="space-y-3">
              <Button
                className="w-full bg-[var(--electric-blue)] hover:bg-[var(--electric-cyan)] text-white"
                onClick={() => onSelectModel('freelancer')}
              >
                Browse Freelancers
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
              <div className="text-center text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">Typical cost:</span> ₹2-8L per role
              </div>
            </div>
          </Card>

          {/* Clusters */}
          <Card className="p-8 border-2 hover:border-[var(--electric-blue)] transition-all hover:shadow-xl bg-gradient-to-br from-white to-blue-50/30">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-[var(--electric-blue)] rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Hardware Clusters</h2>
                <p className="text-sm text-muted-foreground">Pre-coordinated teams</p>
              </div>
            </div>

            <div className="space-y-6 mb-8">
              {/* Pros */}
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[var(--trust-green)]" />
                  Best For
                </h3>
                <ul className="space-y-2 text-sm text-muted-foreground pl-7">
                  <li>• First-time hardware founders</li>
                  <li>• Complex multi-disciplinary projects</li>
                  <li>• Startups without technical co-founders</li>
                  <li>• Fast-paced execution timelines</li>
                </ul>
              </div>

              {/* Pros */}
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[var(--trust-green)]" />
                  Advantages
                </h3>
                <ul className="space-y-2 text-sm text-muted-foreground pl-7">
                  <li>• Single point of accountability</li>
                  <li>• Proven team collaboration history</li>
                  <li>• Faster execution with established workflows</li>
                  <li>• One contract, simpler management</li>
                </ul>
              </div>

              {/* Considerations */}
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-amber-600" />
                  Considerations
                </h3>
                <ul className="space-y-2 text-sm text-muted-foreground pl-7">
                  <li>• Higher upfront investment</li>
                  <li>• Less flexibility in team composition</li>
                  <li>• May include roles you don't need yet</li>
                  <li>• Longer commitment typically required</li>
                </ul>
              </div>
            </div>

            <div className="space-y-3">
              <Button
                className="w-full bg-[var(--electric-blue)] hover:bg-[var(--electric-cyan)] text-white"
                onClick={() => onSelectModel('cluster')}
              >
                Browse Clusters
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
              <div className="text-center text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">Typical cost:</span> ₹15-40L per project
              </div>
            </div>
          </Card>
        </div>

        {/* Comparison Table */}
        <Card className="p-8 mb-8 bg-white">
          <h3 className="text-xl font-bold mb-6 text-center">Quick Comparison</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 font-semibold">Factor</th>
                  <th className="text-center py-3 px-4 font-semibold">Freelancers</th>
                  <th className="text-center py-3 px-4 font-semibold">Clusters</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                <tr className="border-b">
                  <td className="py-3 px-4 text-muted-foreground">Initial Cost</td>
                  <td className="text-center py-3 px-4">
                    <span className="inline-block px-2 py-1 bg-[var(--trust-green)]/10 text-[var(--trust-green)] rounded">Lower</span>
                  </td>
                  <td className="text-center py-3 px-4">
                    <span className="inline-block px-2 py-1 bg-amber-100 text-amber-900 rounded">Higher</span>
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="py-3 px-4 text-muted-foreground">Speed to Start</td>
                  <td className="text-center py-3 px-4">2-4 weeks</td>
                  <td className="text-center py-3 px-4">
                    <span className="inline-block px-2 py-1 bg-[var(--trust-green)]/10 text-[var(--trust-green)] rounded">1-2 weeks</span>
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="py-3 px-4 text-muted-foreground">Coordination</td>
                  <td className="text-center py-3 px-4">You manage</td>
                  <td className="text-center py-3 px-4">
                    <span className="inline-block px-2 py-1 bg-[var(--trust-green)]/10 text-[var(--trust-green)] rounded">Handled for you</span>
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="py-3 px-4 text-muted-foreground">Flexibility</td>
                  <td className="text-center py-3 px-4">
                    <span className="inline-block px-2 py-1 bg-[var(--trust-green)]/10 text-[var(--trust-green)] rounded">High</span>
                  </td>
                  <td className="text-center py-3 px-4">Medium</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 text-muted-foreground">Team Chemistry</td>
                  <td className="text-center py-3 px-4">Build from scratch</td>
                  <td className="text-center py-3 px-4">
                    <span className="inline-block px-2 py-1 bg-[var(--trust-green)]/10 text-[var(--trust-green)] rounded">Pre-tested</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </Card>

        {/* CTA Section */}
        <div className="text-center space-y-4">
          <p className="text-muted-foreground">Not sure which model fits your needs?</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              variant="outline"
              onClick={() => onSelectModel('both')}
              className="border-[var(--electric-blue)] text-[var(--electric-blue)] hover:bg-[var(--electric-blue)]/10"
            >
              Show Me Both Options
            </Button>
            <Button variant="ghost" onClick={onBack}>
              Back
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
