import { Cpu, Wrench, Code, TestTube, Box, Palette, Zap, Settings } from 'lucide-react';

interface SpecializationIconProps {
  specialization: string;
  className?: string;
}

const iconMap: Record<string, React.ComponentType<any>> = {
  'Embedded': Cpu,
  'PCB Design': Zap,
  'Firmware': Code,
  'QA Testing': TestTube,
  'Mechanical': Wrench,
  'Industrial Design': Palette,
  'Manufacturing': Settings,
  'Hardware': Box,
};

export function SpecializationIcon({ specialization, className = "w-5 h-5" }: SpecializationIconProps) {
  const Icon = iconMap[specialization] || Box;
  return <Icon className={className} />;
}
