import { MapPin, Search, CheckCircle2 } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { useState } from 'react';

interface CitySelectorProps {
  onCitySelect: (city: string) => void;
  onBack: () => void;
}

export function CitySelector({ onCitySelect, onBack }: CitySelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');

  const cities = [
    { name: 'Bengaluru', experts: 145, clusters: 8, popular: true },
    { name: 'Pune', experts: 87, clusters: 5, popular: true },
    { name: 'Hyderabad', experts: 92, clusters: 6, popular: true },
    { name: 'Ahmedabad', experts: 63, clusters: 4, popular: false },
    { name: 'Noida', experts: 54, clusters: 3, popular: false },
    { name: 'Vadodara', experts: 38, clusters: 2, popular: false },
  ];

  const filteredCities = cities.filter(city =>
    city.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-blue-50/30 to-cyan-50/20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-[var(--electric-blue)]/10 rounded-full mb-6">
            <MapPin className="w-8 h-8 text-[var(--electric-blue)]" />
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            Find Verified Experts in Your City
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Local teams mean faster coordination, easier meetings, and better cultural fit. 
            Choose your city to see available experts.
          </p>
        </div>

        {/* Search */}
        <div className="max-w-md mx-auto mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search cities..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12 bg-white"
            />
          </div>
        </div>

        {/* Cities Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {filteredCities.map((city) => (
            <Card
              key={city.name}
              className="p-6 hover:shadow-lg transition-all cursor-pointer group hover:border-[var(--electric-blue)]"
              onClick={() => onCitySelect(city.name)}
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-xl font-semibold mb-1 group-hover:text-[var(--electric-blue)] transition-colors">
                    {city.name}
                  </h3>
                  {city.popular && (
                    <span className="inline-flex items-center gap-1 text-xs text-[var(--trust-green)]">
                      <CheckCircle2 className="w-3 h-3" />
                      Popular
                    </span>
                  )}
                </div>
                <MapPin className="w-6 h-6 text-[var(--electric-blue)] opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Individual Experts</span>
                  <span className="font-semibold">{city.experts}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Hardware Clusters</span>
                  <span className="font-semibold">{city.clusters}</span>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t">
                <Button
                  size="sm"
                  variant="ghost"
                  className="w-full group-hover:bg-[var(--electric-blue)]/10 group-hover:text-[var(--electric-blue)]"
                >
                  View Experts
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {filteredCities.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">No cities found matching "{searchTerm}"</p>
            <Button variant="outline" onClick={() => setSearchTerm('')}>
              Clear Search
            </Button>
          </div>
        )}

        {/* Info Cards */}
        <div className="grid md:grid-cols-2 gap-6 mt-12">
          <Card className="p-6 bg-white border-2">
            <h3 className="font-semibold mb-2">Why choose local experts?</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[var(--trust-green)] flex-shrink-0 mt-0.5" />
                <span>Easier in-person collaboration and lab visits</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[var(--trust-green)] flex-shrink-0 mt-0.5" />
                <span>Better time zone alignment for meetings</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[var(--trust-green)] flex-shrink-0 mt-0.5" />
                <span>Local manufacturing and supplier networks</span>
              </li>
            </ul>
          </Card>

          <Card className="p-6 bg-white border-2">
            <h3 className="font-semibold mb-2">Don't see your city?</h3>
            <p className="text-sm text-muted-foreground mb-4">
              We're expanding to more cities. You can still work with experts remotely 
              or request to be notified when we launch in your area.
            </p>
            <Button variant="outline" size="sm">
              Request New City
            </Button>
          </Card>
        </div>

        <div className="text-center mt-8">
          <Button variant="ghost" onClick={onBack}>
            Back to Home
          </Button>
        </div>
      </div>
    </div>
  );
}
