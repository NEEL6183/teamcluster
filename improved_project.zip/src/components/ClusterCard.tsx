import { MapPin, Star, Users, Clock, DollarSign, Heart, ExternalLink, Award } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { VerificationBadge } from './VerificationBadge';
import { SkillTag } from './SkillTag';
import { SpecializationIcon } from './SpecializationIcon';

interface ClusterCardProps {
  cluster: {
    id: string;
    name: string;
    tagline: string;
    city: string;
    teamSize: number;
    rating: number;
    reviews: number;
    verified: boolean;
    specializations: string[];
    capabilities: string[];
    costRange: string;
    timeline: string;
    projectsCompleted: number;
    availability: 'Available' | 'Limited' | 'Waitlist';
  };
  onViewProfile: (id: string) => void;
  onShortlist?: (id: string) => void;
}

export function ClusterCard({ cluster, onViewProfile, onShortlist }: ClusterCardProps) {
  const availabilityColors = {
    'Available': 'bg-[var(--trust-green)] text-white',
    'Limited': 'bg-amber-500 text-white',
    'Waitlist': 'bg-gray-400 text-white'
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all group border-2">
      {/* Header Banner */}
      <div className="h-2 bg-gradient-to-r from-[var(--electric-blue)] via-[var(--electric-cyan)] to-[var(--electric-blue)]" />
      
      <div className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--electric-blue)] to-[var(--electric-cyan)] rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-xl truncate">{cluster.name}</h3>
                <p className="text-sm text-muted-foreground">{cluster.tagline}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <MapPin className="w-4 h-4" />
              <span>{cluster.city}</span>
              <span className="mx-2">•</span>
              <Users className="w-4 h-4" />
              <span>{cluster.teamSize} members</span>
            </div>
          </div>

          {onShortlist && (
            <Button
              variant="ghost"
              size="sm"
              className="flex-shrink-0 p-2 h-auto"
              onClick={() => onShortlist(cluster.id)}
            >
              <Heart className="w-4 h-4" />
            </Button>
          )}
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-2 mb-4">
          {cluster.verified && <VerificationBadge type="verified" />}
          <span className={`px-2 py-1 rounded text-xs font-medium ${availabilityColors[cluster.availability]}`}>
            {cluster.availability}
          </span>
          <span className="px-2 py-1 rounded text-xs font-medium bg-purple-100 text-purple-900">
            Full Team
          </span>
        </div>

        {/* Specializations */}
        <div className="mb-4">
          <p className="text-xs text-muted-foreground mb-2">Team Specializations</p>
          <div className="flex flex-wrap gap-2">
            {cluster.specializations.map((spec) => (
              <div key={spec} className="flex items-center gap-1 px-2 py-1 bg-secondary rounded text-sm">
                <SpecializationIcon specialization={spec} className="w-4 h-4" />
                <span>{spec}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 mb-4 pb-4 border-b">
          <div>
            <div className="flex items-center gap-1 mb-1">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span className="font-semibold">{cluster.rating}</span>
              <span className="text-sm text-muted-foreground">({cluster.reviews})</span>
            </div>
            <p className="text-xs text-muted-foreground">Team Rating</p>
          </div>
          <div>
            <div className="font-semibold mb-1">{cluster.projectsCompleted}</div>
            <p className="text-xs text-muted-foreground">Projects Delivered</p>
          </div>
        </div>

        {/* Capabilities */}
        <div className="mb-4">
          <p className="text-xs text-muted-foreground mb-2">Key Capabilities</p>
          <div className="flex flex-wrap gap-2">
            {cluster.capabilities.slice(0, 3).map((cap) => (
              <SkillTag key={cap} skill={cap} variant="outline" />
            ))}
            {cluster.capabilities.length > 3 && (
              <SkillTag skill={`+${cluster.capabilities.length - 3} more`} variant="outline" />
            )}
          </div>
        </div>

        {/* Cost & Timeline */}
        <div className="grid grid-cols-2 gap-4 mb-4 text-sm bg-muted/30 p-3 rounded-lg">
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-muted-foreground" />
            <div>
              <div className="text-xs text-muted-foreground">Project Range</div>
              <div className="font-semibold">{cluster.costRange}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-muted-foreground" />
            <div>
              <div className="text-xs text-muted-foreground">Delivery Time</div>
              <div className="font-semibold">{cluster.timeline}</div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            className="flex-1 bg-[var(--electric-blue)] hover:bg-[var(--electric-cyan)] text-white"
            onClick={() => onViewProfile(cluster.id)}
          >
            View Team Profile
          </Button>
          <Button variant="outline" size="icon">
            <ExternalLink className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}
