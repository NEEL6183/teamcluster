import { useState } from 'react';
import { Navigation } from './components/Navigation';
import { HomePage } from './components/HomePage';
import { NeedsClarifier } from './components/NeedsClarifier';
import { CitySelector } from './components/CitySelector';
import { ClusterVsFreelancer } from './components/ClusterVsFreelancer';
import { ListingsPage } from './components/ListingsPage';
import { ProfilePage } from './components/ProfilePage';

type Screen = 
  | 'home'
  | 'needs-clarifier'
  | 'city-selector'
  | 'cluster-vs-freelancer'
  | 'listings'
  | 'profile';

interface AppState {
  screen: Screen;
  selectedCity?: string;
  teamModel?: 'freelancer' | 'cluster' | 'both';
  userNeeds?: any;
  selectedProfileId?: string;
  selectedProfileType?: 'freelancer' | 'cluster';
}

export default function App() {
  const [state, setState] = useState<AppState>({
    screen: 'home'
  });

  const navigateTo = (screen: Screen, updates: Partial<AppState> = {}) => {
    setState(prev => ({ ...prev, screen, ...updates }));
  };

  const handleGetStarted = () => {
    navigateTo('city-selector');
  };

  const handleStartGuidedFlow = () => {
    navigateTo('needs-clarifier');
  };

  const handleNeedsClarifierComplete = (needs: any) => {
    setState(prev => ({ ...prev, userNeeds: needs }));
    navigateTo('city-selector');
  };

  const handleCitySelect = (city: string) => {
    setState(prev => ({ ...prev, selectedCity: city }));
    
    // If user already specified team model in needs clarifier, go to listings
    if (state.userNeeds?.teamModel && state.userNeeds.teamModel !== 'both') {
      navigateTo('listings', { teamModel: state.userNeeds.teamModel });
    } else {
      // Otherwise show cluster vs freelancer explanation
      navigateTo('cluster-vs-freelancer');
    }
  };

  const handleTeamModelSelect = (model: 'freelancer' | 'cluster' | 'both') => {
    navigateTo('listings', { teamModel: model });
  };

  const handleViewProfile = (id: string, type: 'freelancer' | 'cluster') => {
    navigateTo('profile', {
      selectedProfileId: id,
      selectedProfileType: type
    });
  };

  const handleChangeCity = () => {
    navigateTo('city-selector');
  };

  const handleBackToHome = () => {
    navigateTo('home');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation - shown on most screens */}
      {state.screen !== 'needs-clarifier' && (
        <Navigation
          selectedCity={state.selectedCity}
          onCityClick={handleChangeCity}
          showMobileMenu={true}
        />
      )}

      {/* Main Content */}
      {state.screen === 'home' && (
        <HomePage
          onGetStarted={handleGetStarted}
          onStartGuidedFlow={handleStartGuidedFlow}
        />
      )}

      {state.screen === 'needs-clarifier' && (
        <NeedsClarifier
          onComplete={handleNeedsClarifierComplete}
          onBack={handleBackToHome}
        />
      )}

      {state.screen === 'city-selector' && (
        <CitySelector
          onCitySelect={handleCitySelect}
          onBack={handleBackToHome}
        />
      )}

      {state.screen === 'cluster-vs-freelancer' && (
        <ClusterVsFreelancer
          onSelectModel={handleTeamModelSelect}
          onBack={() => navigateTo('city-selector')}
        />
      )}

      {state.screen === 'listings' && state.selectedCity && state.teamModel && (
        <ListingsPage
          city={state.selectedCity}
          teamModel={state.teamModel}
          onViewProfile={handleViewProfile}
          onChangeCity={handleChangeCity}
        />
      )}

      {state.screen === 'profile' && state.selectedProfileId && state.selectedProfileType && (
        <ProfilePage
          profileId={state.selectedProfileId}
          profileType={state.selectedProfileType}
          onBack={() => navigateTo('listings')}
        />
      )}
    </div>
  );
}
